import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PlaceappointmentComponent } from './placeappointment/placeappointment.component';
import { ViewappointmentComponent } from './viewappointment/viewappointment.component';
import { ContactusComponent } from './contactus/contactus.component';
import { FooterComponent } from './footer/footer.component';
import { RouterModule , Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

const appRoutes: Routes =[	
  {path:'' , component:HomeComponent},
  {path:'home' , component:HomeComponent},
  {path:'placeappointment' , component:PlaceappointmentComponent},
  {path:'viewappointment', component:ViewappointmentComponent},
  {path:'contactus', component:ContactusComponent},
  ];

@NgModule({
  declarations: [
    AppComponent,
    PlaceappointmentComponent,
    ViewappointmentComponent,
    ContactusComponent,
    FooterComponent,
     HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
